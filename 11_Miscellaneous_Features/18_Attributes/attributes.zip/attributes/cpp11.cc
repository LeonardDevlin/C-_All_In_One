// Function that never returns
[[ noreturn ]]
void server() {
	while (true) {
		// Process incoming connections
	}
}

int main() {
	server();
}