#ifndef ADD_H
#define ADD_H

#ifdef __cplusplus
extern "C" int add(int x, int y);
#else
int add(int x, int y);
#endif

#endif //ADD_H