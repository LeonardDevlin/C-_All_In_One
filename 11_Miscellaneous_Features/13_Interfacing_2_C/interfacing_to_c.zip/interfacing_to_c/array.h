#ifndef ARRAY_H
#define ARRAY_H

int array_print(int arr[], int n);

#endif //ARRAY_H