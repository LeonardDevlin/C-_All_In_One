#include <stdio.h>

#include "add.h"

int main() {
	printf("add(2, 3) returns %d\n", add(2, 3));
}