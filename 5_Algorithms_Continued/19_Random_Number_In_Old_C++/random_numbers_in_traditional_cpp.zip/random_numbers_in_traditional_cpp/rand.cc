#include <iostream>
#include <cstdlib>

using namespace std;

int main() {
	// Print out a pseudo-random integer
	cout << "Printing out a random number... ";
	cout << rand() << endl;
}