#include <iostream>

using namespace std;

int main() {
	double pi {3.141'592'653'5};
	cout << pi << endl;                                // Displays 3.14159
	
	double c {299'792'458};
	cout << c << endl;                                 // Displays 2.99792e+008
}