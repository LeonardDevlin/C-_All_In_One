#include <iostream>

using namespace std;

class Test {
	int i;
	public:
	explicit Test(int i) : i(i) {}
};

int main() {
	Test test = 4;
}