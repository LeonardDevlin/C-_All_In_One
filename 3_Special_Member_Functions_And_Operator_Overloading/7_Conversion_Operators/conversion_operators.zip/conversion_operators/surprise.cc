#include <iostream>

using namespace std;

int main() {
	int i = 99;
	cin << i;                                                    // This compiles!?
}