#include <iostream>
#include "extern_int.h"

using namespace std;

int main() {
	func();
	cout << "The meaning of life is: " << meaning_of_life << endl;
}
