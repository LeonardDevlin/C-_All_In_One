#include "extern_int.h"

void func() {
	meaning_of_life = 42;
}
