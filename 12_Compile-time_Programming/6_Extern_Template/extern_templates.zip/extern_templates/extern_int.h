#pragma once
extern int meaning_of_life;                    // Declare meaning_of_life

// Declare a function
void func();