#include "extern_template.h"

// Non-extern instantiation of the template
template std::ostream& print(std::ostream& os, const std::string& str);