#include "extern_int.h"

int meaning_of_life;                                 // Define meaning_of_life