class Vehicle {                             // This will be the base class
    int max_speed;
    // ...  Member Functions
};

class Aeroplane : public Vehicle {          // This will be the derived class
    int max_height;
    // ...  Member Functions
};